// Definir constantes.

const width = 800
const height = 600
const margin = {
    top: 10,
    right: 10,
    left: 40,
    bottom: 40
}

// Definir svg y grupos para los ejes.

const svg = d3.select("div#chart").append("svg").attr("width", width). attr("height", height)
const elementGroup = svg.append("g").attr("class", "elementGroup").attr("transform", `translate(${margin.left},${margin.top})`)
const axisGroup = svg.append("g").attr("class", "axisGroup")
const xAxisGroup = axisGroup.append("g").attr("class", "xAxisGroup").attr("transform", `translate(${margin.left},${height - margin.bottom})`)
const yAxisGroup = axisGroup.append("g").attr("class", "yAxisGroup").attr("transform", `translate(${margin.left},${margin.top})`)

let title = svg.append("text"). attr("class", "title").text("Valor de cierre de mercado"). attr("transform",`translate(${margin.left+50},${20})`)

// Definir escalas para los ejes.

const x = d3.scaleTime().range([0, width - margin.left - margin.right])
const y = d3.scaleLinear().range([height - margin.top - margin.bottom, 0])

const xAxis = d3.axisBottom().scale(x)
const yAxis = d3.axisLeft().scale(y)

// Cargamos los datos.

const transformarTiempo = d3.timeParse("%d/%m/%Y") // Realizamos las transformaciones necesarias, en este caso, parseamos la fecha

d3.csv("ibex.csv").then(data => {
    data.map(d => {
        d.close = +d.close
        d.date = transformarTiempo(d.date)
    })
    //Dominios
    x.domain(d3.extent(data.map(d => d.date)))  
    y.domain(d3.extent(data.map(d => d.close))) 
    // Llamamos a los ejes
    xAxisGroup.call(xAxis)
    yAxisGroup.call(yAxis)
    //Elegimos el tipo de grafico
    elementGroup.datum(data)
        .append('path')
        .attr("id", "linea")
        .attr("d", d3.line()
            .x(d => x(d.date))
            .y(d => y(d.close)))


    console.log(data)
})