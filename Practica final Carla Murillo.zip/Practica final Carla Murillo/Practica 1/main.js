// Cargar los datos desde el archivo CSV
d3.csv("WorldCup.csv").then(function(data) {
    const svg = d3.select("#chart");
    const margin = { top: 20, right: 20, bottom: 60, left: 40 };
    const width = +svg.attr("width") - margin.left - margin.right;
    const height = +svg.attr("height") - margin.top - margin.bottom;

    const x = d3.scaleBand().range([0, width]).padding(0.1);
    const y = d3.scaleLinear().range([height, 0]);

    const g = svg.append("g")
        .attr("transform", "translate(" + margin.left + "," + margin.top + ")");

    // Función para calcular el acumulado de mundiales ganados por cada país
    function calculateCumulativeData(selectedYear) {
        const filteredData = data.filter(d => +d.Year <= +selectedYear);
        const countries = Array.from(new Set(filteredData.map(d => d.Winner)));
        const cumulativeData = [];

        countries.forEach(country => {
            const titles = filteredData.filter(d => d.Winner === country).length;
            cumulativeData.push({ country, titles });
        });


        return cumulativeData;
    }

    // Función para actualizar la gráfica de barras según el año seleccionado
    function updateChart(selectedYear) {
        const cumulativeData = calculateCumulativeData(selectedYear);

        x.domain(cumulativeData.map(d => d.country));
        y.domain([0, d3.max(cumulativeData, d => d.titles)]);

        // Ejes X e Y
        const xAxis = d3.axisBottom(x);
        const yAxis = d3.axisLeft(y).ticks(d3.max(cumulativeData, d => d.titles));

        g.selectAll(".axis").remove();

        g.append("g")
            .attr("class", "axis")
            .attr("transform", "translate(0," + height + ")")
            .call(xAxis);

        g.append("g")
            .attr("class", "axis")
            .call(yAxis);

        // Eliminar las barras existentes antes de actualizar
        g.selectAll(".bar").remove();

        // Crear las nuevas barras
        g.selectAll(".bar")
            .data(cumulativeData)
            .enter().append("rect")
            .attr("class", d => "bar country" + (cumulativeData.findIndex(c => c.country === d.country) + 1))
            .attr("x", d => x(d.country))
            .attr("y", d => y(d.titles))
            .attr("width", x.bandwidth())
            .attr("height", d => height - y(d.titles));
        
    }

    // Inicializar la gráfica con el año predeterminado
    const initialYear = "1930";
    updateChart(initialYear);

    // Conectar el slider al evento de actualización de la gráfica
    const slider = document.getElementById("slider");
    const yearLabel = document.getElementById("year-label");

    slider.addEventListener("input", function() {
        const selectedYear = slider.value;
        updateChart(selectedYear);
        yearLabel.textContent = selectedYear;
    });
});